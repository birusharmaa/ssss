<link rel="shortcut icon" href="<?=base_url();?>/public/assets/images/favicon.png" />
<link rel="stylesheet" href="<?=base_url();?>/public/assets/vendors/iconfonts/font-awesome/css/all.min.css">
<link rel="stylesheet" href="<?=base_url();?>/public/assets/vendors/css/vendor.bundle.base.css">
<link rel="stylesheet" href="<?=base_url();?>/public/assets/vendors/css/vendor.bundle.addons.css">
<link rel="stylesheet" href="<?=base_url();?>/public/assets/css/style.min.css">
<link rel="stylesheet" href="<?=base_url();?>/public/assets/css/custom.min.css">
<link rel="stylesheet" href="<?=base_url();?>/public/assets/css/custom.css">